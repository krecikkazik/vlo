﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Licznik
{
    public partial class FormLicznik : Form
    {
        public FormLicznik()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 1;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBoxLicznik.Text = "0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 2;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 3;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 4;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 5;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 6;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 7;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 8;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x + 9;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void buttonGwiazdka_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxLicznik.Text);
            x = x * x;
            textBoxLicznik.Text = Convert.ToString(x);
        }

        private void buttonHasz_Click(object sender, EventArgs e)
        {
            int dl=textBoxLicznik.Text.Length;
            string wynik = "";
            for (int i=dl-1; i>=0; i--)
                wynik = wynik + Convert.ToString(textBoxLicznik.Text[i]);
            textBoxLicznik.Text = wynik;
        }
    }
}
